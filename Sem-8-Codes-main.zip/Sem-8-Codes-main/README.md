The ZIP file is organized sequentially according to the syllabus, starting with the Deep Learning (DL) practicals followed by the High Performance Computing (HPC) practicals.
